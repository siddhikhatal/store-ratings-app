import { useState, useEffect } from 'react';
import { Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { api, validate } from './api';

const getUser = () => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } };

/* ---------- generic pieces ---------- */
function AuthForm({ fields, submitLabel, onSubmit, validateKeys }) {
  const [v, setV] = useState({}); const [msg, setMsg] = useState({});
  const submit = async e => {
    e.preventDefault();
    const errs = validate(v, validateKeys);
    if (errs.length) return setMsg({ err: errs.join('. ') });
    try { setMsg({ ok: await onSubmit(v) || 'Success' }); } catch (x) { setMsg({ err: x.message }); }
  };
  return (<form className="col" onSubmit={submit}>
    {fields.map(([k, label, type = 'text']) => (
      <label key={k}>{label}<br />
        {type === 'select' ? <select value={v[k] || 'user'} onChange={e => setV({ ...v, [k]: e.target.value })}>
          <option value="user">Normal User</option><option value="admin">Admin</option><option value="owner">Store Owner</option></select>
          : <input style={{ width: '100%' }} type={type} value={v[k] || ''} onChange={e => setV({ ...v, [k]: e.target.value })} />}
      </label>))}
    {msg.err && <div className="err">{msg.err}</div>}{msg.ok && <div className="ok">{msg.ok}</div>}
    <button>{submitLabel}</button></form>);
}

function SortTable({ cols, rows, sort, order, onSort, onRow, extra }) {
  return (<table><thead><tr>{cols.map(([k, label, sortable = true]) =>
    <th key={k} className={sortable ? 's' : ''} onClick={() => sortable && onSort(k)}>
      {label}{sort === k ? (order === 'asc' ? ' ▲' : ' ▼') : ''}</th>)}{extra && <th />}</tr></thead>
    <tbody>{rows.map((r, i) => <tr key={r.id ?? i} onClick={() => onRow?.(r)} style={onRow ? { cursor: 'pointer' } : {}}>
      {cols.map(([k]) => <td key={k}>{r[k]}</td>)}{extra && <td>{extra(r)}</td>}</tr>)}
      {!rows.length && <tr><td colSpan={cols.length + 1}>No records</td></tr>}</tbody></table>);
}

function ListView({ endpoint, filterKeys, cols, onRow, refreshKey, extra, defSort = 'name', refresh }) {
  const [f, setF] = useState({}); const [sort, setSort] = useState(defSort); const [order, setOrder] = useState('asc'); const [rows, setRows] = useState([]);
  useEffect(() => {
    api(`${endpoint}?${new URLSearchParams({ ...f, sort, order })}`).then(setRows).catch(() => setRows([]));
  }, [endpoint, f, sort, order, refreshKey, refresh]);
  const onSort = k => { if (k === sort) setOrder(order === 'asc' ? 'desc' : 'asc'); else { setSort(k); setOrder('asc'); } };
  return (<div className="card"><div className="filters">
    {filterKeys.map(k => k === 'role'
      ? <select key={k} onChange={e => setF({ ...f, role: e.target.value })}><option value="">All roles</option>
        <option value="admin">Admin</option><option value="user">Normal User</option><option value="owner">Store Owner</option></select>
      : <input key={k} placeholder={`Filter by ${k}`} onChange={e => setF({ ...f, [k]: e.target.value })} />)}</div>
    <SortTable {...{ cols, rows, sort, order, onSort, onRow, extra }} /></div>);
}

/* ---------- pages ---------- */
function Login() {
  const nav = useNavigate();
  return (<main><div className="card"><h2>Login</h2>
    <AuthForm submitLabel="Login" validateKeys={[]} fields={[['email', 'Email'], ['password', 'Password', 'password']]}
      onSubmit={async v => { const d = await api('/auth/login', { method: 'POST', body: v });
        localStorage.setItem('token', d.token); localStorage.setItem('user', JSON.stringify(d.user)); nav('/'); }} />
    <p>New here? <Link to="/signup">Create an account</Link></p></div></main>);
}
function Signup() {
  return (<main><div className="card"><h2>Sign up</h2>
    <AuthForm submitLabel="Register" validateKeys={['name', 'email', 'address', 'password']}
      fields={[['name', 'Name (20-60 chars)'], ['email', 'Email'], ['address', 'Address'], ['password', 'Password', 'password']]}
      onSubmit={async v => { await api('/auth/signup', { method: 'POST', body: v }); return 'Registered! You can now log in.'; }} />
    <p><Link to="/login">Back to login</Link></p></div></main>);
}
function Password() {
  return (<main><div className="card"><h2>Update password</h2>
    <AuthForm submitLabel="Update" validateKeys={['password']} fields={[['password', 'New password', 'password']]}
      onSubmit={async v => { await api('/auth/password', { method: 'PUT', body: v }); return 'Password updated'; }} /></div></main>);
}

function Admin() {
  const [stats, setStats] = useState({}); const [tab, setTab] = useState('users'); const [k, setK] = useState(0);
  const [detail, setDetail] = useState(null); const [add, setAdd] = useState(false);
  useEffect(() => { api('/admin/stats').then(setStats); }, [k]);
  const done = () => setK(k + 1);
  return (<main><div className="stats">
    <div className="card"><b>{stats.users}</b>Total users</div><div className="card"><b>{stats.stores}</b>Total stores</div>
    <div className="card"><b>{stats.ratings}</b>Total ratings</div></div>
    <div className="tabs">{['users', 'stores'].map(t => <button key={t} className={tab === t ? 'on' : 'ghost'} onClick={() => { setTab(t); setAdd(false); setDetail(null); }}>{t === 'users' ? 'Users' : 'Stores'}</button>)}
      <button className="ghost" onClick={() => setAdd(!add)}>{add ? 'Close form' : `+ Add ${tab === 'users' ? 'user' : 'store'}`}</button></div>
    {add && <div className="card">{tab === 'users'
      ? <AuthForm submitLabel="Create user" validateKeys={['name', 'email', 'address', 'password']}
        fields={[['name', 'Name (20-60 chars)'], ['email', 'Email'], ['address', 'Address'], ['password', 'Password', 'password'], ['role', 'Role', 'select']]}
        onSubmit={async v => { await api('/admin/users', { method: 'POST', body: v }); done(); return 'User created'; }} />
      : <AuthForm submitLabel="Create store" validateKeys={['email', 'address']}
        fields={[['name', 'Store name'], ['email', 'Store email'], ['address', 'Address'], ['ownerId', 'Owner user ID (optional, must be a Store Owner)']]}
        onSubmit={async v => { await api('/admin/stores', { method: 'POST', body: v }); done(); return 'Store created'; }} />}</div>}
    {detail && <div className="card"><b>User details</b><br />Name: {detail.name}<br />Email: {detail.email}<br />Address: {detail.address}<br />
      Role: {detail.role}{detail.role === 'owner' && <><br />Rating: {detail.rating}</>}</div>}
    {tab === 'users'
      ? <ListView endpoint="/admin/users" refreshKey={k} filterKeys={['name', 'email', 'address', 'role']}
        cols={[['id', 'ID', false], ['name', 'Name'], ['email', 'Email'], ['address', 'Address'], ['role', 'Role']]}
        onRow={r => api(`/admin/users/${r.id}`).then(setDetail)} />
      : <ListView endpoint="/admin/stores" refreshKey={k} filterKeys={['name', 'email', 'address']}
        cols={[['name', 'Name'], ['email', 'Email'], ['address', 'Address'], ['rating', 'Rating']]} />}
  </main>);
}

function UserStores() {
  const [refresh, setRefresh] = useState(0); const [err, setErr] = useState('');
  const rate = async (id, rating) => { try { await api(`/stores/${id}/rating`, { method: 'PUT', body: { rating } }); setRefresh(refresh + 1); } catch (e) { setErr(e.message); } };
  return (<main><h2>Stores</h2>{err && <div className="err">{err}</div>}
    <ListView endpoint="/stores" refresh={refresh} filterKeys={['name', 'address']}
      cols={[['name', 'Store'], ['address', 'Address'], ['overall', 'Overall rating'], ['myRating', 'Your rating']]}
      extra={r => <select value={r.myRating || ''} onChange={e => rate(r.id, Number(e.target.value))}>
        <option value="" disabled>{r.myRating ? 'Modify' : 'Rate'}</option>{[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{n}</option>)}</select>} />
  </main>);
}

function Owner() {
  const [d, setD] = useState(null); const [sort, setSort] = useState('name'); const [order, setOrder] = useState('asc');
  useEffect(() => { api(`/owner/dashboard?${new URLSearchParams({ sort, order })}`).then(setD); }, [sort, order]);
  const onSort = k => { if (k === sort) setOrder(order === 'asc' ? 'desc' : 'asc'); else { setSort(k); setOrder('asc'); } };
  if (!d) return <main>Loading…</main>;
  if (!d.store) return <main><div className="card">No store is assigned to your account yet.</div></main>;
  return (<main><div className="card"><h2>{d.store.name}</h2>{d.store.address}<br /><b>Average rating: {d.average}</b></div>
    <div className="card"><h3>Users who rated your store</h3>
      <SortTable cols={[['name', 'Name'], ['email', 'Email'], ['rating', 'Rating']]} rows={d.raters} {...{ sort, order, onSort }} /></div></main>);
}

/* ---------- shell ---------- */
export default function App() {
  const nav = useNavigate(); const user = getUser();
  const logout = () => { localStorage.clear(); nav('/login'); };
  const Home = { admin: Admin, user: UserStores, owner: Owner }[user?.role];
  return (<>
    <nav><b>Store Ratings</b><span className="sp" />
      {user ? <><span>{user.name} ({user.role})</span><Link to="/">Dashboard</Link><Link to="/password">Password</Link><a href="#" onClick={logout}>Logout</a></>
        : <><Link to="/login">Login</Link><Link to="/signup">Sign up</Link></>}</nav>
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
      <Route path="/signup" element={user ? <Navigate to="/" /> : <Signup />} />
      <Route path="/password" element={user ? <Password /> : <Navigate to="/login" />} />
      <Route path="/" element={Home ? <Home /> : <Navigate to="/login" />} />
    </Routes></>);
}
