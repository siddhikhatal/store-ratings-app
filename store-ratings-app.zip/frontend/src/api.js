const BASE = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';
export async function api(path, { method = 'GET', body } = {}) {
  const token = localStorage.getItem('token');
  const res = await fetch(BASE + path, {
    method, headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
    body: body && JSON.stringify(body) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
export const rules = {
  name: v => (v.length < 20 || v.length > 60) && 'Name must be 20-60 characters',
  email: v => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) && 'Enter a valid email',
  address: v => (!v || v.length > 400) && 'Address is required (max 400 characters)',
  password: v => !/^(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,16}$/.test(v) && 'Password: 8-16 chars, 1 uppercase, 1 special character',
};
export const validate = (values, keys) => keys.map(k => rules[k]?.(values[k] || '')).filter(Boolean);
