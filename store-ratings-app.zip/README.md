# Store Ratings – FullStack Intern Challenge
Stack: Express + PostgreSQL (backend), React + Vite (frontend). Single login, roles: admin / user / owner.

## Run locally
1. Create a database: `createdb store_ratings`
2. Backend: `cd backend && cp .env.example .env && npm i && npm run db && npm run seed && npm start`
3. Frontend: `cd frontend && npm i && npm run dev` (set `VITE_API_URL` if the API isn't on localhost:4000)

Seeded admin: `admin@example.com` / `Admin@12345`.
Create a Store Owner via Admin → Add user (role Store Owner), then Add store with that owner's user ID.

## Notes
- Validation (name 20-60, address ≤400, password 8-16 w/ uppercase + special, email) enforced on both client and server.
- Passwords hashed with bcrypt, JWT auth, role-based route guards, parameterised SQL, sort columns whitelisted.
- One rating per user per store (unique constraint); users can modify it (upsert).
