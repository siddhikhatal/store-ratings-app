require('dotenv').config();
const bcrypt = require('bcrypt'); const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
(async () => {
  const hash = await bcrypt.hash('Admin@12345', 10);
  await pool.query(`INSERT INTO users(name,email,address,password_hash,role)
    VALUES('System Administrator Account','admin@example.com','Head Office',$1,'admin') ON CONFLICT (email) DO NOTHING`, [hash]);
  console.log('Seeded admin@example.com / Admin@12345'); await pool.end();
})();
