require('dotenv').config();
const express = require('express'), cors = require('cors'), bcrypt = require('bcrypt'), jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const SECRET = process.env.JWT_SECRET || 'dev-secret';
const app = express(); app.use(cors(), express.json());

// ---------- helpers ----------
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
function validate({ name, email, address, password }, need = ['name', 'email', 'address', 'password']) {
  const e = [];
  if (need.includes('name') && !(typeof name === 'string' && name.length >= 20 && name.length <= 60)) e.push('Name must be 20-60 characters');
  if (need.includes('email') && !(typeof email === 'string' && EMAIL_RE.test(email))) e.push('Invalid email');
  if (need.includes('address') && !(typeof address === 'string' && address.length > 0 && address.length <= 400)) e.push('Address is required (max 400 characters)');
  if (need.includes('password') && !(typeof password === 'string' && /^(?=.*[A-Z])(?=.*[^A-Za-z0-9]).{8,16}$/.test(password)))
    e.push('Password must be 8-16 characters with at least one uppercase letter and one special character');
  return e;
}
const orderBy = (q, allowed, def) => `ORDER BY ${allowed.includes(q.sort) ? q.sort : def} ${q.order === 'desc' ? 'DESC' : 'ASC'}`;
const like = v => `%${v || ''}%`;
const wrap = fn => (req, res) => fn(req, res).catch(err => { console.error(err); res.status(500).json({ error: 'Server error' }); });
const auth = (...roles) => (req, res, next) => {
  try {
    req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET);
    if (roles.length && !roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
    next();
  } catch { res.status(401).json({ error: 'Unauthorized' }); }
};
async function createUser(res, body, role) {
  const errs = validate(body); if (errs.length) return res.status(400).json({ error: errs.join('. ') });
  const hash = await bcrypt.hash(body.password, 10);
  try {
    const { rows } = await pool.query(
      'INSERT INTO users(name,email,address,password_hash,role) VALUES($1,$2,$3,$4,$5) RETURNING id,name,email,address,role',
      [body.name, body.email.toLowerCase(), body.address, hash, role]);
    res.status(201).json(rows[0]);
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'Email already exists' }); throw e; }
}

// ---------- auth ----------
app.post('/api/auth/signup', wrap(async (req, res) => createUser(res, req.body, 'user')));
app.post('/api/auth/login', wrap(async (req, res) => {
  const { email, password } = req.body;
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [(email || '').toLowerCase()]);
  const u = rows[0];
  if (!u || !(await bcrypt.compare(password || '', u.password_hash))) return res.status(401).json({ error: 'Invalid credentials' });
  const user = { id: u.id, name: u.name, email: u.email, role: u.role };
  res.json({ token: jwt.sign(user, SECRET, { expiresIn: '8h' }), user });
}));
app.put('/api/auth/password', auth(), wrap(async (req, res) => {
  const errs = validate({ password: req.body.password }, ['password']); if (errs.length) return res.status(400).json({ error: errs[0] });
  await pool.query('UPDATE users SET password_hash=$1 WHERE id=$2', [await bcrypt.hash(req.body.password, 10), req.user.id]);
  res.json({ ok: true });
}));

// ---------- admin ----------
app.get('/api/admin/stats', auth('admin'), wrap(async (_req, res) => {
  const { rows } = await pool.query(`SELECT (SELECT count(*) FROM users)::int users,
    (SELECT count(*) FROM stores)::int stores, (SELECT count(*) FROM ratings)::int ratings`);
  res.json(rows[0]);
}));
app.post('/api/admin/users', auth('admin'), wrap(async (req, res) => {
  const role = ['admin', 'user', 'owner'].includes(req.body.role) ? req.body.role : 'user';
  createUser(res, req.body, role);
}));
app.get('/api/admin/users', auth('admin'), wrap(async (req, res) => {
  const q = req.query;
  const { rows } = await pool.query(
    `SELECT id,name,email,address,role FROM users WHERE name ILIKE $1 AND email ILIKE $2 AND address ILIKE $3
     AND ($4='' OR role=$4) ${orderBy(q, ['name', 'email', 'address', 'role'], 'name')}`,
    [like(q.name), like(q.email), like(q.address), q.role || '']);
  res.json(rows);
}));
app.get('/api/admin/users/:id', auth('admin'), wrap(async (req, res) => {
  const { rows } = await pool.query('SELECT id,name,email,address,role FROM users WHERE id=$1', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Not found' });
  if (rows[0].role === 'owner') {
    const r = await pool.query(`SELECT ROUND(AVG(r.rating),1) rating FROM stores s JOIN ratings r ON r.store_id=s.id WHERE s.owner_id=$1`, [req.params.id]);
    rows[0].rating = r.rows[0].rating || 0;
  }
  res.json(rows[0]);
}));
app.post('/api/admin/stores', auth('admin'), wrap(async (req, res) => {
  const { name, email, address, ownerId } = req.body;
  if (!(name && name.length <= 60)) return res.status(400).json({ error: 'Store name required (max 60 characters)' });
  const errs = validate({ email, address }, ['email', 'address']); if (errs.length) return res.status(400).json({ error: errs.join('. ') });
  try {
    const { rows } = await pool.query('INSERT INTO stores(name,email,address,owner_id) VALUES($1,$2,$3,$4) RETURNING *',
      [name, email.toLowerCase(), address, ownerId || null]);
    res.status(201).json(rows[0]);
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Store email or owner already in use' });
    if (e.code === '23503') return res.status(400).json({ error: 'Owner not found' });
    throw e;
  }
}));
app.get('/api/admin/stores', auth('admin'), wrap(async (req, res) => {
  const q = req.query;
  const { rows } = await pool.query(
    `SELECT s.id,s.name,s.email,s.address,COALESCE(ROUND(AVG(r.rating),1),0)::float rating
     FROM stores s LEFT JOIN ratings r ON r.store_id=s.id
     WHERE s.name ILIKE $1 AND s.email ILIKE $2 AND s.address ILIKE $3 GROUP BY s.id
     ${orderBy(q, ['name', 'email', 'address', 'rating'], 'name')}`, [like(q.name), like(q.email), like(q.address)]);
  res.json(rows);
}));

// ---------- normal user ----------
app.get('/api/stores', auth('user'), wrap(async (req, res) => {
  const q = req.query;
  const { rows } = await pool.query(
    `SELECT s.id,s.name,s.address,COALESCE(ROUND(AVG(r.rating),1),0)::float "overall",
       (SELECT rating FROM ratings WHERE store_id=s.id AND user_id=$1) "myRating"
     FROM stores s LEFT JOIN ratings r ON r.store_id=s.id
     WHERE s.name ILIKE $2 AND s.address ILIKE $3 GROUP BY s.id
     ${orderBy(q, ['name', 'address', 'overall'], 'name')}`, [req.user.id, like(q.name), like(q.address)]);
  res.json(rows);
}));
app.put('/api/stores/:id/rating', auth('user'), wrap(async (req, res) => {
  const rating = Number(req.body.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be 1-5' });
  try {
    await pool.query(`INSERT INTO ratings(user_id,store_id,rating) VALUES($1,$2,$3)
      ON CONFLICT (user_id,store_id) DO UPDATE SET rating=$3, updated_at=now()`, [req.user.id, req.params.id, rating]);
    res.json({ ok: true });
  } catch (e) { if (e.code === '23503') return res.status(404).json({ error: 'Store not found' }); throw e; }
}));

// ---------- store owner ----------
app.get('/api/owner/dashboard', auth('owner'), wrap(async (req, res) => {
  const s = await pool.query('SELECT id,name,address FROM stores WHERE owner_id=$1', [req.user.id]);
  if (!s.rows[0]) return res.json({ store: null, average: 0, raters: [] });
  const raters = await pool.query(
    `SELECT u.name,u.email,r.rating,r.updated_at FROM ratings r JOIN users u ON u.id=r.user_id
     WHERE r.store_id=$1 ${orderBy(req.query, ['name', 'email', 'rating'], 'name')}`.replace('ORDER BY name', 'ORDER BY u.name').replace('ORDER BY email', 'ORDER BY u.email').replace('ORDER BY rating', 'ORDER BY r.rating'),
    [s.rows[0].id]);
  const avg = raters.rows.length ? raters.rows.reduce((a, r) => a + r.rating, 0) / raters.rows.length : 0;
  res.json({ store: s.rows[0], average: Math.round(avg * 10) / 10, raters: raters.rows });
}));

app.listen(process.env.PORT || 4000, () => console.log('API running'));
